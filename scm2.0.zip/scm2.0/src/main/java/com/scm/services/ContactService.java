package com.scm.services;

import java.util.List;

import com.scm.entities.Contact;

public interface ContactService {
  //save contacts
  Contact save(Contact contact);
  //update contact
  Contact update(Contact contact);
  List<Contact> getAll();
  //contact by id
  Contact getById(String id);
  //delete contact by id
  void delete(String id);
  List<Contact> search(String name,String email,String phoneNumber);
  // get contacts by userId
  List<Contact> getByUserId(String userId);

}
